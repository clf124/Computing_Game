import assert from "assert";
import {
    CANDY_TYPES,
    BOARD_SIZE,
    newGame,
    isValidPosition,
    getCell,
    setCell,
    swapCells,
    areAdjacent,
    findHorizontalMatches,
    findVerticalMatches,
    findMatches,
    removeMatches,
    applyGravity,
    calculateMatchScore,
    wouldCreateMatch,
    findHint,
    hasValidMoves,
    ensureNoInitialMatches,
    makeMove,
    getCandyEmoji,
    isGameOver,
    selectCell,
    randomBoard,
} from "../Module.js";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Creates a known 8×8 board safe to use in makeMove tests. No row/col has 3+ in a row. */
const makeCheckerboard = () => [
    [0, 1, 0, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 0, 1, 0],
    [2, 3, 2, 3, 2, 3, 2, 3],
    [3, 2, 3, 2, 3, 2, 3, 2],
    [4, 5, 4, 5, 4, 5, 4, 5],
    [5, 4, 5, 4, 5, 4, 5, 4],
    [0, 1, 0, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 0, 1, 0],
];

/**
 * Board where swapping (0,0)↔(0,1) completes a run:
 *   row 0 becomes [0, 1, 1, 1, 2, 3, 4, 5] → match of 1s at cols 1,2,3
 * No pre-existing matches anywhere.
 */
const makeMoveBoard = () => [
    [1, 0, 1, 1, 2, 3, 4, 5],
    [2, 3, 4, 5, 0, 1, 2, 3],
    [3, 4, 5, 0, 1, 2, 3, 4],
    [4, 5, 0, 1, 2, 3, 4, 5],
    [5, 0, 1, 2, 3, 4, 5, 0],
    [0, 1, 2, 3, 4, 5, 0, 1],
    [1, 2, 3, 4, 5, 0, 1, 2],
    [2, 3, 4, 5, 0, 1, 2, 3],
];

/**
 * A deterministic randFn that cycles through distinct values so that
 * newly filled cells never accidentally form a run of 3+ identical candies.
 * Returns a fresh cycling function each call so tests are independent.
 */
const makeSafeRand = () => {
    const cycle = [0, 1, 2, 3, 4, 5];
    let i = 0;
    return () => cycle[i++ % cycle.length];
};

// ---------------------------------------------------------------------------
// CANDY_TYPES
// ---------------------------------------------------------------------------
describe("CANDY_TYPES", function () {
    it("contains exactly 6 entries", function () {
        assert.strictEqual(CANDY_TYPES.length, 6);
    });

    it("every entry is a non-empty string", function () {
        CANDY_TYPES.forEach((t) => {
            assert.ok(typeof t === "string" && t.length > 0,
                `Expected non-empty string, got: ${t}`);
        });
    });

    it("all entries are distinct", function () {
        const unique = new Set(CANDY_TYPES);
        assert.strictEqual(unique.size, CANDY_TYPES.length);
    });
});

// ---------------------------------------------------------------------------
// BOARD_SIZE
// ---------------------------------------------------------------------------
describe("BOARD_SIZE", function () {
    it("is a positive integer", function () {
        assert.ok(Number.isInteger(BOARD_SIZE) && BOARD_SIZE > 0);
    });

    it("is 8", function () {
        assert.strictEqual(BOARD_SIZE, 8);
    });
});

// ---------------------------------------------------------------------------
// isValidPosition
// ---------------------------------------------------------------------------
describe("isValidPosition", function () {
    it("returns true for (0,0) on an 8×8 board", function () {
        assert.ok(isValidPosition(8, 0, 0));
    });

    it("returns true for the bottom-right corner (7,7)", function () {
        assert.ok(isValidPosition(8, 7, 7));
    });

    it("returns false when row is negative", function () {
        assert.ok(!isValidPosition(8, -1, 0));
    });

    it("returns false when col is negative", function () {
        assert.ok(!isValidPosition(8, 0, -1));
    });

    it("returns false when row equals board size", function () {
        assert.ok(!isValidPosition(8, 8, 0));
    });

    it("returns false when col equals board size", function () {
        assert.ok(!isValidPosition(8, 0, 8));
    });

    it("works for custom board sizes", function () {
        assert.ok(isValidPosition(4, 3, 3));
        assert.ok(!isValidPosition(4, 4, 0));
    });
});

// ---------------------------------------------------------------------------
// areAdjacent
// ---------------------------------------------------------------------------
describe("areAdjacent", function () {
    it("horizontal right-neighbour is adjacent", function () {
        assert.ok(areAdjacent(0, 0, 0, 1));
    });

    it("horizontal left-neighbour is adjacent", function () {
        assert.ok(areAdjacent(0, 1, 0, 0));
    });

    it("vertical down-neighbour is adjacent", function () {
        assert.ok(areAdjacent(0, 0, 1, 0));
    });

    it("vertical up-neighbour is adjacent", function () {
        assert.ok(areAdjacent(1, 0, 0, 0));
    });

    it("diagonal cells are NOT adjacent", function () {
        assert.ok(!areAdjacent(0, 0, 1, 1));
    });

    it("same cell is NOT adjacent", function () {
        assert.ok(!areAdjacent(0, 0, 0, 0));
    });

    it("cells two apart in a row are NOT adjacent", function () {
        assert.ok(!areAdjacent(0, 0, 0, 2));
    });

    it("cells two apart in a column are NOT adjacent", function () {
        assert.ok(!areAdjacent(0, 0, 2, 0));
    });
});

// ---------------------------------------------------------------------------
// getCell / setCell
// ---------------------------------------------------------------------------
describe("getCell", function () {
    const board = [[1, 2], [3, 4]];

    it("returns the correct value for (0,0)", function () {
        assert.strictEqual(getCell(board, 0, 0), 1);
    });

    it("returns the correct value for (0,1)", function () {
        assert.strictEqual(getCell(board, 0, 1), 2);
    });

    it("returns the correct value for (1,0)", function () {
        assert.strictEqual(getCell(board, 1, 0), 3);
    });
});

describe("setCell", function () {
    const board = [[1, 2], [3, 4]];

    it("returns a board with the updated value", function () {
        const result = setCell(board, 0, 0, 99);
        assert.strictEqual(result[0][0], 99);
    });

    it("does not mutate the original board", function () {
        setCell(board, 0, 0, 99);
        assert.strictEqual(board[0][0], 1);
    });

    it("leaves other cells unchanged", function () {
        const result = setCell(board, 0, 0, 99);
        assert.strictEqual(result[0][1], 2);
        assert.strictEqual(result[1][0], 3);
        assert.strictEqual(result[1][1], 4);
    });
});

// ---------------------------------------------------------------------------
// swapCells
// ---------------------------------------------------------------------------
describe("swapCells", function () {
    it("exchanges the values at two positions", function () {
        const board = [[1, 2], [3, 4]];
        const result = swapCells(board, 0, 0, 0, 1);
        assert.strictEqual(result[0][0], 2);
        assert.strictEqual(result[0][1], 1);
    });

    it("does not mutate the original board", function () {
        const board = [[1, 2], [3, 4]];
        swapCells(board, 0, 0, 0, 1);
        assert.strictEqual(board[0][0], 1);
        assert.strictEqual(board[0][1], 2);
    });

    it("swapping a cell with itself leaves the board unchanged", function () {
        const board = [[5, 3], [1, 2]];
        const result = swapCells(board, 0, 0, 0, 0);
        assert.strictEqual(result[0][0], 5);
    });
});

// ---------------------------------------------------------------------------
// findHorizontalMatches
// ---------------------------------------------------------------------------
describe("findHorizontalMatches", function () {
    it("detects a run of exactly 3 identical candies", function () {
        const board = [[0, 0, 0, 1, 2, 3, 4, 5]];
        const matches = findHorizontalMatches(board, 8);
        assert.ok(matches.has("0,0") && matches.has("0,1") && matches.has("0,2"));
        assert.strictEqual(matches.size, 3);
    });

    it("does not flag a run of only 2", function () {
        const board = [[0, 0, 1, 2, 3, 4, 5, 1]];
        assert.strictEqual(findHorizontalMatches(board, 8).size, 0);
    });

    it("detects a run of 4 and includes all 4 cells", function () {
        const board = [[0, 0, 0, 0, 1, 2, 3, 4]];
        const matches = findHorizontalMatches(board, 8);
        assert.strictEqual(matches.size, 4);
    });

    it("detects two separate runs in the same row", function () {
        const board = [[0, 0, 0, 1, 1, 1, 2, 3]];
        const matches = findHorizontalMatches(board, 8);
        assert.strictEqual(matches.size, 6);
    });

    it("returns an empty set when no horizontal runs exist", function () {
        const board = [[0, 1, 2, 3, 4, 5, 0, 1]];
        assert.strictEqual(findHorizontalMatches(board, 8).size, 0);
    });
});

// ---------------------------------------------------------------------------
// findVerticalMatches
// ---------------------------------------------------------------------------
describe("findVerticalMatches", function () {
    it("detects a run of exactly 3 identical candies in a column", function () {
        const board = [[0], [0], [0], [1], [2], [3], [4], [5]];
        const matches = findVerticalMatches(board, 1);
        assert.ok(matches.has("0,0") && matches.has("1,0") && matches.has("2,0"));
        assert.strictEqual(matches.size, 3);
    });

    it("does not flag a vertical run of only 2", function () {
        const board = [[0], [0], [1], [2], [3], [4], [5], [1]];
        assert.strictEqual(findVerticalMatches(board, 1).size, 0);
    });

    it("detects runs across multiple columns independently", function () {
        // col 0: [0,0,0,1,2,3,4,5] → run of 0s at rows 0-2 = 3 matches
        // col 1: [1,1,1,2,3,4,5,0] → run of 1s at rows 0-2 = 3 matches
        const board = [[0, 1], [0, 1], [0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 0]];
        const matches = findVerticalMatches(board, 2);
        assert.strictEqual(matches.size, 6);
    });
});

// ---------------------------------------------------------------------------
// findMatches
// ---------------------------------------------------------------------------
describe("findMatches", function () {
    it("returns an empty set when the board has no matches", function () {
        const board = makeCheckerboard();
        assert.strictEqual(findMatches(board, 8).size, 0);
    });

    it("includes horizontal matches", function () {
        const board = makeCheckerboard();
        // Force a horizontal run
        board[0][0] = 5;
        board[0][1] = 5;
        board[0][2] = 5;
        const matches = findMatches(board, 8);
        assert.ok(matches.has("0,0") && matches.has("0,1") && matches.has("0,2"));
    });

    it("includes vertical matches", function () {
        const board = makeCheckerboard();
        board[0][0] = 5;
        board[1][0] = 5;
        board[2][0] = 5;
        const matches = findMatches(board, 8);
        assert.ok(matches.has("0,0") && matches.has("1,0") && matches.has("2,0"));
    });

    it("combines horizontal and vertical without duplication", function () {
        const board = makeCheckerboard();
        // Create a cross: row 0 cols 0-2 and col 0 rows 0-2 all value 5
        board[0][0] = 5; board[0][1] = 5; board[0][2] = 5;
        board[1][0] = 5;
        board[2][0] = 5;
        const matches = findMatches(board, 8);
        // 5 unique cells in the cross (intersection cell counted once)
        assert.strictEqual(matches.size, 5);
    });
});

// ---------------------------------------------------------------------------
// removeMatches
// ---------------------------------------------------------------------------
describe("removeMatches", function () {
    it("sets matched cells to -1", function () {
        const board = [[0, 1, 2], [3, 4, 5], [0, 1, 2]];
        const matches = new Set(["0,0", "0,1", "0,2"]);
        const result = removeMatches(board, matches, 3);
        assert.strictEqual(result[0][0], -1);
        assert.strictEqual(result[0][1], -1);
        assert.strictEqual(result[0][2], -1);
    });

    it("does not alter non-matched cells", function () {
        const board = [[0, 1, 2], [3, 4, 5], [0, 1, 2]];
        const matches = new Set(["0,0"]);
        const result = removeMatches(board, matches, 3);
        assert.strictEqual(result[1][0], 3);
        assert.strictEqual(result[2][2], 2);
    });

    it("does not mutate the original board", function () {
        const board = [[0, 1, 2], [3, 4, 5], [0, 1, 2]];
        removeMatches(board, new Set(["0,0"]), 3);
        assert.strictEqual(board[0][0], 0);
    });
});

// ---------------------------------------------------------------------------
// applyGravity
// ---------------------------------------------------------------------------
describe("applyGravity", function () {
    const always3 = () => 3; // deterministic randFn for tests

    it("keeps non-empty cells in their relative vertical order", function () {
        const board = [[-1], [1], [2]];
        const result = applyGravity(board, 1, always3);
        assert.strictEqual(result[1][0], 1);
        assert.strictEqual(result[2][0], 2);
    });

    it("fills empty top rows with new candies (not -1)", function () {
        const board = [[-1], [-1], [0]];
        const result = applyGravity(board, 1, always3);
        assert.ok(result[0][0] >= 0, "Top-filled cell should not be -1");
        assert.ok(result[1][0] >= 0, "Top-filled cell should not be -1");
    });

    it("uses the provided randFn for filled cells", function () {
        const board = [[-1], [-1], [0]];
        const result = applyGravity(board, 1, always3);
        assert.strictEqual(result[0][0], 3);
        assert.strictEqual(result[1][0], 3);
    });

    it("leaves columns with no gaps unchanged", function () {
        const board = [[0], [1], [2]];
        const result = applyGravity(board, 1, always3);
        assert.strictEqual(result[0][0], 0);
        assert.strictEqual(result[1][0], 1);
        assert.strictEqual(result[2][0], 2);
    });

    it("handles a fully empty column", function () {
        const board = [[-1], [-1], [-1]];
        const result = applyGravity(board, 1, always3);
        result.forEach((row) => assert.strictEqual(row[0], 3));
    });

    it("does not mutate the original board", function () {
        const board = [[-1], [1], [2]];
        applyGravity(board, 1, always3);
        assert.strictEqual(board[0][0], -1);
    });
});

// ---------------------------------------------------------------------------
// calculateMatchScore
// ---------------------------------------------------------------------------
describe("calculateMatchScore", function () {
    it("returns 0 for an empty match set", function () {
        assert.strictEqual(calculateMatchScore(new Set()), 0);
    });

    it("returns 90 for exactly 3 matched cells", function () {
        const s = new Set(["0,0", "0,1", "0,2"]);
        assert.strictEqual(calculateMatchScore(s), 90);
    });

    it("awards a bonus for 4+ matched cells (more than 3-match score)", function () {
        const s3 = new Set(["0,0", "0,1", "0,2"]);
        const s4 = new Set(["0,0", "0,1", "0,2", "0,3"]);
        assert.ok(
            calculateMatchScore(s4) > calculateMatchScore(s3),
            "4-match should score more than 3-match"
        );
    });

    it("score increases monotonically with match size", function () {
        const scores = [3, 4, 5, 6].map(
            (n) => calculateMatchScore(new Set(Array.from({ length: n }, (_, i) => `0,${i}`)))
        );
        for (let i = 1; i < scores.length; i++) {
            assert.ok(scores[i] > scores[i - 1]);
        }
    });
});

// ---------------------------------------------------------------------------
// wouldCreateMatch
// ---------------------------------------------------------------------------
describe("wouldCreateMatch", function () {
    it("returns true when swapping creates a horizontal match", function () {
        const board = makeMoveBoard();
        // (0,0)=1 swaps with (0,1)=0 → row 0 becomes [0,1,1,1,...] → match at cols 1,2,3
        assert.ok(wouldCreateMatch(board, 0, 0, 0, 1, 8));
    });

    it("returns false when swapping does not create any match", function () {
        const board = makeCheckerboard();
        // Swapping (0,0)=0 with (0,1)=1 on a checkerboard creates no run of 3
        assert.ok(!wouldCreateMatch(board, 0, 0, 0, 1, 8));
    });

    it("does not mutate the original board", function () {
        const board = makeMoveBoard();
        const original = board[0][0];
        wouldCreateMatch(board, 0, 0, 0, 1, 8);
        assert.strictEqual(board[0][0], original);
    });
});

// ---------------------------------------------------------------------------
// findHint
// ---------------------------------------------------------------------------
describe("findHint", function () {
    it("returns a hint object with row, col, and direction", function () {
        const board = makeMoveBoard();
        const hint = findHint(board, 8);
        assert.ok(hint !== null, "Should find a hint on this board");
        assert.ok("row" in hint && "col" in hint && "direction" in hint);
    });

    it("hint direction is one of the four cardinal strings", function () {
        const board = makeMoveBoard();
        const hint = findHint(board, 8);
        const valid = ["up", "down", "left", "right"];
        assert.ok(valid.includes(hint.direction), `Unexpected direction: ${hint.direction}`);
    });

    it("the hinted swap would create a match", function () {
        const board = makeMoveBoard();
        const hint = findHint(board, 8);
        const dr = { up: -1, down: 1, left: 0, right: 0 }[hint.direction];
        const dc = { up: 0, down: 0, left: -1, right: 1 }[hint.direction];
        assert.ok(wouldCreateMatch(board, hint.row, hint.col,
            hint.row + dr, hint.col + dc, 8));
    });

    it("returns null when no valid swap exists", function () {
        // A 1×1 board has no adjacent cells → no moves possible
        assert.strictEqual(findHint([[0]], 1), null);
    });
});

// ---------------------------------------------------------------------------
// hasValidMoves
// ---------------------------------------------------------------------------
describe("hasValidMoves", function () {
    it("returns true when the board contains a legal swap", function () {
        assert.ok(hasValidMoves(makeMoveBoard(), 8));
    });

    it("returns false on a 1×1 board (no neighbours)", function () {
        assert.ok(!hasValidMoves([[0]], 1));
    });
});

// ---------------------------------------------------------------------------
// ensureNoInitialMatches
// ---------------------------------------------------------------------------
describe("ensureNoInitialMatches", function () {
    it("removes all pre-existing matches from an all-same board", function () {
        const allZeroes = Array.from({ length: 8 }, () => Array(8).fill(0));
        const result = ensureNoInitialMatches(allZeroes, 8);
        assert.strictEqual(findMatches(result, 8).size, 0);
    });

    it("preserves board dimensions after fixing", function () {
        const board = Array.from({ length: 8 }, () => Array(8).fill(1));
        const result = ensureNoInitialMatches(board, 8);
        assert.strictEqual(result.length, 8);
        result.forEach((row) => assert.strictEqual(row.length, 8));
    });

    it("does not change a board that already has no matches", function () {
        const board = makeCheckerboard();
        const result = ensureNoInitialMatches(board, 8);
        assert.strictEqual(findMatches(result, 8).size, 0);
    });
});

// ---------------------------------------------------------------------------
// makeMove
// ---------------------------------------------------------------------------
describe("makeMove", function () {
    it("returns valid: false for non-adjacent cells", function () {
        const state = newGame(8, makeCheckerboard());
        const result = makeMove(state, 0, 0, 0, 2);
        assert.ok(!result.valid);
    });

    it("returns the original state unchanged when move is invalid", function () {
        const state = newGame(8, makeCheckerboard());
        const result = makeMove(state, 0, 0, 0, 2);
        assert.strictEqual(result.state, state);
    });

    it("returns valid: false when adjacent swap creates no match", function () {
        const state = newGame(8, makeCheckerboard());
        const result = makeMove(state, 0, 0, 0, 1);
        assert.ok(!result.valid);
    });

    it("returns valid: true when adjacent swap creates a match", function () {
        const state = newGame(8, makeMoveBoard());
        const result = makeMove(state, 0, 0, 0, 1, makeSafeRand());
        assert.ok(result.valid);
    });

    it("increases score on a valid move", function () {
        const state = newGame(8, makeMoveBoard());
        const result = makeMove(state, 0, 0, 0, 1, makeSafeRand());
        assert.ok(result.state.score > 0);
    });

    it("decrements movesLeft by exactly 1 on a valid move", function () {
        const state = newGame(8, makeMoveBoard());
        const result = makeMove(state, 0, 0, 0, 1, makeSafeRand());
        assert.strictEqual(result.state.movesLeft, state.movesLeft - 1);
    });

    it("populates matchedCells with at least one round", function () {
        const state = newGame(8, makeMoveBoard());
        const result = makeMove(state, 0, 0, 0, 1, makeSafeRand());
        assert.ok(result.matchedCells.length >= 1);
    });

    it("matchedCells entries are arrays of 'row,col' strings", function () {
        const state = newGame(8, makeMoveBoard());
        const result = makeMove(state, 0, 0, 0, 1, makeSafeRand());
        for (const round of result.matchedCells) {
            for (const key of round) {
                assert.match(key, /^\d+,\d+$/);
            }
        }
    });

    it("clears selectedCell in the returned state", function () {
        const state = { ...newGame(8, makeMoveBoard()), selectedCell: { row: 0, col: 0 } };
        const result = makeMove(state, 0, 0, 0, 1, makeSafeRand());
        assert.strictEqual(result.state.selectedCell, null);
    });

    it("does not mutate the original state object", function () {
        const state = newGame(8, makeMoveBoard());
        const origScore = state.score;
        const origMoves = state.movesLeft;
        makeMove(state, 0, 0, 0, 1, makeSafeRand());
        assert.strictEqual(state.score, origScore);
        assert.strictEqual(state.movesLeft, origMoves);
    });

    it("advances level when score reaches targetScore", function () {
        const board = makeMoveBoard();
        const state = { ...newGame(8, board), score: 990, targetScore: 1000 };
        const result = makeMove(state, 0, 0, 0, 1, makeSafeRand());
        // Score should cross 1000, triggering level-up
        if (result.state.score >= 1000) {
            assert.ok(result.state.level > state.level);
        }
    });
});

// ---------------------------------------------------------------------------
// getCandyEmoji
// ---------------------------------------------------------------------------
describe("getCandyEmoji", function () {
    it("returns a string for every valid index (0–5)", function () {
        for (let i = 0; i < CANDY_TYPES.length; i++) {
            assert.ok(typeof getCandyEmoji(i) === "string");
        }
    });

    it("returns the same value as CANDY_TYPES for valid indices", function () {
        for (let i = 0; i < CANDY_TYPES.length; i++) {
            assert.strictEqual(getCandyEmoji(i), CANDY_TYPES[i]);
        }
    });

    it("returns '❓' for an out-of-range index", function () {
        assert.strictEqual(getCandyEmoji(99), "❓");
    });

    it("returns '❓' for a negative index", function () {
        assert.strictEqual(getCandyEmoji(-1), "❓");
    });
});

// ---------------------------------------------------------------------------
// newGame
// ---------------------------------------------------------------------------
describe("newGame", function () {
    it("creates an 8×8 board by default", function () {
        const state = newGame();
        assert.strictEqual(state.board.length, 8);
        state.board.forEach((row) => assert.strictEqual(row.length, 8));
    });

    it("starts with score 0", function () {
        assert.strictEqual(newGame().score, 0);
    });

    it("starts at level 1", function () {
        assert.strictEqual(newGame().level, 1);
    });

    it("starts with 30 moves", function () {
        assert.strictEqual(newGame().movesLeft, 30);
    });

    it("has no pre-existing matches on the default board", function () {
        const state = newGame();
        assert.strictEqual(findMatches(state.board, 8).size, 0);
    });

    it("uses the provided board directly without modification", function () {
        const board = makeCheckerboard();
        const state = newGame(8, board);
        assert.deepStrictEqual(state.board, board);
    });

    it("creates a 6×6 board when size=6", function () {
        const state = newGame(6);
        assert.strictEqual(state.board.length, 6);
        state.board.forEach((row) => assert.strictEqual(row.length, 6));
    });

    it("selectedCell is null on a new game", function () {
        assert.strictEqual(newGame().selectedCell, null);
    });
});

// ---------------------------------------------------------------------------
// isGameOver
// ---------------------------------------------------------------------------
describe("isGameOver", function () {
    it("returns true when movesLeft is 0", function () {
        const state = { ...newGame(), movesLeft: 0 };
        assert.ok(isGameOver(state));
    });

    it("returns false on a freshly started game", function () {
        assert.ok(!isGameOver(newGame()));
    });

    it("returns true on a 1×1 board (no valid moves)", function () {
        const state = newGame(1, [[0]]);
        assert.ok(isGameOver(state));
    });
});

// ---------------------------------------------------------------------------
// selectCell
// ---------------------------------------------------------------------------
describe("selectCell", function () {
    it("selects a cell when none is currently selected", function () {
        const state = newGame(8, makeCheckerboard());
        const { state: s2 } = selectCell(state, 3, 3);
        assert.deepStrictEqual(s2.selectedCell, { row: 3, col: 3 });
    });

    it("deselects when the same cell is tapped twice", function () {
        const state = { ...newGame(8, makeCheckerboard()), selectedCell: { row: 3, col: 3 } };
        const { state: s2 } = selectCell(state, 3, 3);
        assert.strictEqual(s2.selectedCell, null);
    });

    it("returns moveResult=null when only selecting (not attempting a swap)", function () {
        const state = newGame(8, makeCheckerboard());
        const { moveResult } = selectCell(state, 0, 0);
        assert.strictEqual(moveResult, null);
    });

    it("changes selection to the new cell on an invalid swap attempt", function () {
        // Checkerboard → swapping any adjacent pair creates no match
        const state = { ...newGame(8, makeCheckerboard()), selectedCell: { row: 0, col: 0 } };
        const { state: s2 } = selectCell(state, 0, 1);
        assert.deepStrictEqual(s2.selectedCell, { row: 0, col: 1 });
    });

    it("returns a valid moveResult on a successful swap", function () {
        const board = makeMoveBoard();
        const state = { ...newGame(8, board), selectedCell: { row: 0, col: 0 } };
        const { moveResult } = selectCell(state, 0, 1);
        assert.ok(moveResult !== null && moveResult.valid);
    });

    it("does not mutate the original state", function () {
        const state = newGame(8, makeCheckerboard());
        const origSel = state.selectedCell;
        selectCell(state, 0, 0);
        assert.strictEqual(state.selectedCell, origSel);
    });
});

// ---------------------------------------------------------------------------
// randomBoard
// ---------------------------------------------------------------------------
describe("randomBoard", function () {
    it("generates a board of the correct size", function () {
        const board = randomBoard(8, () => 0);
        assert.strictEqual(board.length, 8);
        board.forEach((row) => assert.strictEqual(row.length, 8));
    });

    it("uses the provided randFn for cell values", function () {
        const board = randomBoard(4, () => 2);
        board.flat().forEach((v) => assert.strictEqual(v, 2));
    });
});
