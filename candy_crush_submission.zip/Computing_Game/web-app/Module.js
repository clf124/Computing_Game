/**
 * @module CandyCrushGame
 * @description Pure functional game logic for a Candy Crush style match-3 game.
 *
 * Most functions are pure — given the same inputs they always return the same
 * output and produce no side effects. The only intentionally impure helpers are
 * those that deal with randomness (`randomBoard`, the default `randFn` in
 * `applyGravity`). These accept an optional `randFn` parameter so callers can
 * inject a deterministic function for testing.
 *
 * The board is represented as a 2D array where each cell holds a candy-type
 * index (0–5) or -1 for an empty slot waiting to be filled by gravity.
 */

import { curry, pipe, range, map, flatten } from "ramda";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/**
 * The six candy types used in the game, stored as emoji strings.
 * @constant {string[]}
 */
export const CANDY_TYPES = ["🍭", "🍬", "🍫", "🍊", "🍋", "🍇"];

/**
 * Default board dimension (8×8).
 * @constant {number}
 */
export const BOARD_SIZE = 8;

/** Minimum run length to count as a match. */
const MATCH_MIN = 3;

// ---------------------------------------------------------------------------
// Type definitions (JSDoc only)
// ---------------------------------------------------------------------------

/**
 * A 2D array of candy-type indices.
 * Each element is an integer 0–5 (candy type) or −1 (empty).
 * @typedef {number[][]} Board
 */

/**
 * Immutable snapshot of the entire game at one moment in time.
 * @typedef {Object} GameState
 * @property {Board}                        board        - Current board layout.
 * @property {number}                       score        - Cumulative score.
 * @property {number}                       level        - Current level (starts at 1).
 * @property {number}                       movesLeft    - Remaining moves this level.
 * @property {number}                       targetScore  - Score needed to clear the level.
 * @property {{row:number,col:number}|null} selectedCell - Currently highlighted cell, or null.
 */

/**
 * Return value of {@link makeMove}.
 * @typedef {Object} MoveResult
 * @property {GameState}   state        - New game state after the move and all cascades.
 * @property {boolean}     valid        - `true` if the move was legal and created a match.
 * @property {string[][]}  matchedCells - One array per cascade round; each element is a
 *   `"row,col"` string identifying a cell that was cleared in that round.
 */

/**
 * A move hint produced by {@link findHint}.
 * @typedef {Object} Hint
 * @property {number} row       - Row of the candy to move.
 * @property {number} col       - Column of the candy to move.
 * @property {string} direction - Direction to swap: `"up"` | `"down"` | `"left"` | `"right"`.
 */

// ---------------------------------------------------------------------------
// Board helpers (pure)
// ---------------------------------------------------------------------------

/**
 * Returns `true` if (row, col) lies within the board.
 *
 * @function
 * @param {number} size - Board dimension.
 * @param {number} row  - Row index.
 * @param {number} col  - Column index.
 * @returns {boolean}
 *
 * @example
 * isValidPosition(8, 0, 0);  // true
 * isValidPosition(8, 8, 0);  // false
 */
export const isValidPosition = curry((size, row, col) =>
    row >= 0 && row < size && col >= 0 && col < size
);

/**
 * Reads the candy index at (row, col) on the board.
 *
 * @function
 * @param {Board}  board
 * @param {number} row
 * @param {number} col
 * @returns {number} Candy type index (0–5) or -1 if empty.
 *
 * @example
 * getCell([[1, 2], [3, 4]], 0, 1); // 2
 */
export const getCell = curry((board, row, col) => board[row][col]);

/**
 * Returns a new board with the candy at (row, col) replaced by `value`.
 * The original board is not mutated.
 *
 * @function
 * @param {Board}  board
 * @param {number} row
 * @param {number} col
 * @param {number} value - New candy index.
 * @returns {Board}
 *
 * @example
 * const b = setCell([[0,1],[2,3]], 0, 0, 99);
 * b[0][0]; // 99
 */
export const setCell = curry((board, row, col, value) => {
    const copy = board.map((r) => [...r]);
    copy[row][col] = value;
    return copy;
});

/**
 * Returns a new board with the candies at two positions swapped.
 * The original board is not mutated.
 *
 * @function
 * @param {Board}  board
 * @param {number} r1 - Row of first cell.
 * @param {number} c1 - Column of first cell.
 * @param {number} r2 - Row of second cell.
 * @param {number} c2 - Column of second cell.
 * @returns {Board}
 *
 * @example
 * const b = swapCells([[1,2],[3,4]], 0, 0, 0, 1);
 * b[0]; // [2, 1]
 */
export const swapCells = curry((board, r1, c1, r2, c2) => {
    const copy = board.map((r) => [...r]);
    copy[r1][c1] = board[r2][c2];
    copy[r2][c2] = board[r1][c1];
    return copy;
});

/**
 * Returns `true` if the two cells share an edge (horizontally or vertically adjacent).
 *
 * @param {number} r1
 * @param {number} c1
 * @param {number} r2
 * @param {number} c2
 * @returns {boolean}
 *
 * @example
 * areAdjacent(0, 0, 0, 1); // true
 * areAdjacent(0, 0, 1, 1); // false (diagonal)
 */
export const areAdjacent = (r1, c1, r2, c2) =>
    (Math.abs(r1 - r2) === 1 && c1 === c2) ||
    (Math.abs(c1 - c2) === 1 && r1 === r2);

// ---------------------------------------------------------------------------
// Match detection (pure)
// ---------------------------------------------------------------------------

/**
 * Finds all cells that form a horizontal run of {@link MATCH_MIN} or more
 * identical candies.
 *
 * @param {Board}  board
 * @param {number} size
 * @returns {Set<string>} Set of `"row,col"` identifiers for matched cells.
 *
 * @example
 * const b = [[0,0,0,1,2,3,4,5]];
 * findHorizontalMatches(b, 8); // Set { "0,0", "0,1", "0,2" }
 */
export const findHorizontalMatches = (board, size) => {
    const matches = new Set();
    for (let r = 0; r < board.length; r++) {
        let c = 0;
        while (c < size) {
            const candy = board[r][c];
            let len = 1;
            while (c + len < size && board[r][c + len] === candy) len++;
            if (len >= MATCH_MIN) {
                for (let i = 0; i < len; i++) matches.add(`${r},${c + i}`);
            }
            c += len;
        }
    }
    return matches;
};

/**
 * Finds all cells that form a vertical run of {@link MATCH_MIN} or more
 * identical candies.
 *
 * @param {Board}  board
 * @param {number} size
 * @returns {Set<string>} Set of `"row,col"` identifiers for matched cells.
 *
 * @example
 * const b = [[0],[0],[0],[1],[2],[3],[4],[5]];
 * findVerticalMatches(b, 1); // Set { "0,0", "1,0", "2,0" }
 */
export const findVerticalMatches = (board, size) => {
    const rows = board.length;
    const matches = new Set();
    for (let c = 0; c < size; c++) {
        let r = 0;
        while (r < rows) {
            const candy = board[r][c];
            let len = 1;
            while (r + len < rows && board[r + len][c] === candy) len++;
            if (len >= MATCH_MIN) {
                for (let i = 0; i < len; i++) matches.add(`${r + i},${c}`);
            }
            r += len;
        }
    }
    return matches;
};

/**
 * Finds all matched cells on the board, combining horizontal and vertical runs.
 * The union is deduplicated so cells at the intersection of two runs appear once.
 *
 * @param {Board}  board
 * @param {number} size
 * @returns {Set<string>} Set of `"row,col"` strings for every matched cell.
 *
 * @example
 * findMatches(board, 8); // Set { "0,0", "0,1", "0,2", ... }
 */
export const findMatches = (board, size) =>
    new Set([
        ...findHorizontalMatches(board, size),
        ...findVerticalMatches(board, size),
    ]);

// ---------------------------------------------------------------------------
// Board mutation helpers (pure)
// ---------------------------------------------------------------------------

/**
 * Returns a new board with every matched cell replaced by -1 (empty).
 * Non-matched cells are unchanged.
 *
 * @param {Board}      board
 * @param {Set<string>} matches - Set of `"row,col"` strings to clear.
 * @param {number}     size
 * @returns {Board}
 */
export const removeMatches = (board, matches, size) => {
    const copy = board.map((r) => [...r]);
    for (const key of matches) {
        const [r, c] = key.split(",").map(Number);
        copy[r][c] = -1;
    }
    return copy;
};

/**
 * Applies gravity to the board: candies fall downward to fill empty (-1) slots.
 * Columns that still have empty slots at the top are filled using `randFn`.
 *
 * Providing a deterministic `randFn` makes this function behave as a pure function,
 * which is useful for unit testing.
 *
 * @param {Board}          board
 * @param {number}         size
 * @param {function():number} [randFn] - Returns a random candy index (0–5).
 *   Defaults to `Math.floor(Math.random() * CANDY_TYPES.length)`.
 * @returns {Board} New board after gravity and refill.
 *
 * @example
 * // Deterministic test usage:
 * const b = applyGravity([[-1],[1],[2]], 1, () => 3);
 * b[0][0]; // 3  (new candy)
 * b[1][0]; // 1
 * b[2][0]; // 2
 */
export const applyGravity = (
    board,
    size,
    randFn = () => Math.floor(Math.random() * CANDY_TYPES.length)
) => {
    const rows = board.length;
    const copy = board.map((r) => [...r]);
    for (let c = 0; c < size; c++) {
        let writeRow = rows - 1;
        for (let r = rows - 1; r >= 0; r--) {
            if (copy[r][c] !== -1) {
                copy[writeRow][c] = copy[r][c];
                if (writeRow !== r) copy[r][c] = -1;
                writeRow--;
            }
        }
        for (let r = writeRow; r >= 0; r--) {
            copy[r][c] = randFn();
        }
    }
    return copy;
};

// ---------------------------------------------------------------------------
// Score (pure)
// ---------------------------------------------------------------------------

/**
 * Calculates the score earned for one cascade round.
 * Base rate is 30 points per candy matched; each candy beyond the minimum
 * three earns an additional 20 bonus points (combo multiplier).
 *
 * @param {Set<string>} matches - Set of matched cell identifiers.
 * @returns {number} Score for this round (0 if no matches).
 *
 * @example
 * calculateMatchScore(new Set(["0,0","0,1","0,2"])); // 90
 * calculateMatchScore(new Set(["0,0","0,1","0,2","0,3"])); // 140
 */
export const calculateMatchScore = (matches) => {
    const count = matches.size;
    if (count === 0) return 0;
    return count * 30 + Math.max(0, count - MATCH_MIN) * 20;
};

// ---------------------------------------------------------------------------
// Move validation (pure)
// ---------------------------------------------------------------------------

/**
 * Returns `true` if swapping the two cells would create at least one match
 * on the resulting board.
 *
 * @param {Board}  board
 * @param {number} r1
 * @param {number} c1
 * @param {number} r2
 * @param {number} c2
 * @param {number} size
 * @returns {boolean}
 *
 * @example
 * // Board where swapping (0,0)↔(0,1) completes a run of three:
 * wouldCreateMatch(board, 0, 0, 0, 1, 8); // true
 */
export const wouldCreateMatch = (board, r1, c1, r2, c2, size) =>
    findMatches(swapCells(board, r1, c1, r2, c2), size).size > 0;

/**
 * Searches the board for any valid swap that would create a match.
 * Returns the first such move found, or `null` if none exist.
 *
 * Corresponds directly to the `suggest_move` function in the original C implementation.
 *
 * @param {Board}  board
 * @param {number} size
 * @returns {Hint|null}
 *
 * @example
 * const hint = findHint(board, 8);
 * if (hint) highlight(hint.row, hint.col);
 */
export const findHint = (board, size) => {
    const directions = [
        { dr: -1, dc: 0, direction: "up" },
        { dr: 1,  dc: 0, direction: "down" },
        { dr: 0,  dc: -1, direction: "left" },
        { dr: 0,  dc: 1,  direction: "right" },
    ];
    for (let r = 0; r < size; r++) {
        for (let c = 0; c < size; c++) {
            for (const { dr, dc, direction } of directions) {
                const r2 = r + dr;
                const c2 = c + dc;
                if (
                    isValidPosition(size, r2, c2) &&
                    wouldCreateMatch(board, r, c, r2, c2, size)
                ) {
                    return { row: r, col: c, direction };
                }
            }
        }
    }
    return null;
};

/**
 * Returns `true` if the board has at least one legal swap that creates a match.
 *
 * @param {Board}  board
 * @param {number} size
 * @returns {boolean}
 */
export const hasValidMoves = (board, size) => findHint(board, size) !== null;

// ---------------------------------------------------------------------------
// Board generation (impure — uses Math.random by default)
// ---------------------------------------------------------------------------

/**
 * Generates a random board of the given size.
 * Supply a deterministic `randFn` to make this pure for testing.
 *
 * @param {number}           [size=BOARD_SIZE]
 * @param {function():number} [randFn]
 * @returns {Board}
 */
export const randomBoard = (
    size = BOARD_SIZE,
    randFn = () => Math.floor(Math.random() * CANDY_TYPES.length)
) =>
    map(() => map(() => randFn(), range(0, size)), range(0, size));

/**
 * Ensures the board has no pre-existing matches by repeatedly replacing matched
 * cells with new random values until the board is match-free.
 *
 * This mirrors the loop in the original C code that called `flip()` after
 * initialisation until no matches remained.
 *
 * @param {Board}            board
 * @param {number}           size
 * @param {function():number} [randFn]
 * @returns {Board} Match-free board.
 */
export const ensureNoInitialMatches = (
    board,
    size,
    randFn = () => Math.floor(Math.random() * CANDY_TYPES.length)
) => {
    let current = board;
    let matches = findMatches(current, size);
    while (matches.size > 0) {
        for (const key of matches) {
            const [r, c] = key.split(",").map(Number);
            current = setCell(current, r, c, randFn());
        }
        matches = findMatches(current, size);
    }
    return current;
};

// ---------------------------------------------------------------------------
// Game lifecycle (mix of pure / impure)
// ---------------------------------------------------------------------------

/**
 * Creates a fresh game state.
 *
 * When `board` is provided the board is used as-is (useful for testing with
 * known configurations). When omitted, a random match-free board is generated.
 *
 * @param {number} [size=BOARD_SIZE] - Board dimension.
 * @param {Board|null} [board=null]  - Optional fixed board (skips random generation).
 * @returns {GameState}
 *
 * @example
 * const game = newGame();          // 8×8 random game
 * const game = newGame(6);         // 6×6 random game
 * const game = newGame(8, myBoard); // fixed board for testing
 */
export const newGame = (size = BOARD_SIZE, board = null) => {
    const rawBoard = board || randomBoard(size);
    const finalBoard = board ? rawBoard : ensureNoInitialMatches(rawBoard, size);
    return {
        board: finalBoard,
        score: 0,
        level: 1,
        movesLeft: 30,
        targetScore: 1000,
        selectedCell: null,
    };
};

/**
 * Processes a player's swap move, applying all cascading matches.
 *
 * Returns `valid: false` (and the original state unchanged) if:
 * - The two cells are not adjacent, or
 * - The swap would not create any match.
 *
 * On a valid move the function:
 * 1. Swaps the two cells.
 * 2. Detects and removes all matching runs.
 * 3. Applies gravity to fill gaps with new random candies.
 * 4. Repeats steps 2–3 until no more matches exist (cascade).
 * 5. Accumulates score (with combo bonuses for larger matches).
 * 6. Decrements `movesLeft` by one.
 * 7. Advances the level if `targetScore` is reached.
 *
 * Supply `randFn` to make the fill step deterministic in tests.
 *
 * @param {GameState}        state
 * @param {number}           r1
 * @param {number}           c1
 * @param {number}           r2
 * @param {number}           c2
 * @param {function():number} [randFn]
 * @returns {MoveResult}
 *
 * @example
 * const { state, valid } = makeMove(game, 3, 2, 3, 3);
 * if (valid) renderBoard(state.board);
 */
export const makeMove = (state, r1, c1, r2, c2, randFn = undefined) => {
    const size = state.board.length;
    if (!areAdjacent(r1, c1, r2, c2)) {
        return { state, valid: false, matchedCells: [] };
    }
    if (!wouldCreateMatch(state.board, r1, c1, r2, c2, size)) {
        return { state, valid: false, matchedCells: [] };
    }

    let board = swapCells(state.board, r1, c1, r2, c2);
    let totalScore = 0;
    const allMatchedCells = [];

    let matches = findMatches(board, size);
    while (matches.size > 0) {
        allMatchedCells.push([...matches]);
        totalScore += calculateMatchScore(matches);
        board = removeMatches(board, matches, size);
        board = applyGravity(board, size, randFn);
        matches = findMatches(board, size);
    }

    const newScore = state.score + totalScore;
    const newMovesLeft = state.movesLeft - 1;
    let { level, targetScore } = state;
    let movesLeft = newMovesLeft;

    if (newScore >= targetScore) {
        level += 1;
        targetScore = Math.floor(targetScore * 1.5);
        movesLeft = 30;
    }

    const newState = {
        ...state,
        board,
        score: newScore,
        level,
        targetScore,
        movesLeft,
        selectedCell: null,
    };

    return { state: newState, valid: true, matchedCells: allMatchedCells };
};

/**
 * Handles a cell-tap event, returning an updated game state.
 *
 * - If no cell is currently selected, the tapped cell becomes selected.
 * - If the same cell is tapped again, it is deselected.
 * - If a different adjacent cell is tapped, a move is attempted:
 *   - On success the result is returned with `moveResult` populated.
 *   - On failure the tapped cell becomes the new selection instead.
 *
 * @param {GameState} state
 * @param {number}    row
 * @param {number}    col
 * @returns {{ state: GameState, moveResult: MoveResult|null }}
 *
 * @example
 * const { state: s2, moveResult } = selectCell(game, 4, 3);
 * if (moveResult?.valid) updateUI(s2);
 */
export const selectCell = (state, row, col) => {
    const sel = state.selectedCell;

    if (!sel) {
        return {
            state: { ...state, selectedCell: { row, col } },
            moveResult: null,
        };
    }

    if (sel.row === row && sel.col === col) {
        return {
            state: { ...state, selectedCell: null },
            moveResult: null,
        };
    }

    const result = makeMove(state, sel.row, sel.col, row, col);
    if (result.valid) {
        return { state: result.state, moveResult: result };
    }

    return {
        state: { ...state, selectedCell: { row, col } },
        moveResult: null,
    };
};

// ---------------------------------------------------------------------------
// Utilities (pure)
// ---------------------------------------------------------------------------

/**
 * Returns the emoji string for the given candy-type index.
 * Returns `"❓"` for any out-of-range index.
 *
 * @param {number} index - Candy type index (0–5).
 * @returns {string} Emoji character.
 *
 * @example
 * getCandyEmoji(0); // "🍭"
 * getCandyEmoji(99); // "❓"
 */
export const getCandyEmoji = (index) => CANDY_TYPES[index] ?? "❓";

/**
 * Returns `true` if the game is over — either because the player has run out
 * of moves or because no legal swap remains on the board.
 *
 * @param {GameState} state
 * @returns {boolean}
 *
 * @example
 * if (isGameOver(state)) showGameOverScreen();
 */
export const isGameOver = (state) =>
    state.movesLeft <= 0 || !hasValidMoves(state.board, state.board.length);
