/**
 * main.js — UI layer for the Candy Crush game.
 *
 * This file is responsible exclusively for rendering and user interaction.
 * All game logic is imported from Module.js; none is duplicated here.
 */

import {
    newGame,
    selectCell,
    findHint,
    isGameOver,
    getCandyEmoji,
    BOARD_SIZE,
} from "./Module.js";

// ---------------------------------------------------------------------------
// State (single mutable reference to an immutable GameState object)
// ---------------------------------------------------------------------------
let state = newGame();
let isAnimating = false;
let hintTimerId = null;

// ---------------------------------------------------------------------------
// DOM references
// ---------------------------------------------------------------------------
const boardEl    = document.getElementById("board");
const scoreEl    = document.getElementById("score");
const targetEl   = document.getElementById("target");
const levelEl    = document.getElementById("level");
const movesEl    = document.getElementById("moves");
const progressEl = document.getElementById("progress-bar");
const messageEl  = document.getElementById("message");
const modal      = document.getElementById("end-modal");
const modalEmoji = document.getElementById("modal-emoji");
const modalTitle = document.getElementById("modal-title");
const modalMsg   = document.getElementById("modal-message");

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------

/** Fully re-renders the board grid and updates the HUD. */
function render() {
    const { board, score, targetScore, level, movesLeft, selectedCell } = state;
    const size = board.length;

    // Update HUD with bump animation on change
    updateStat(scoreEl, score);
    updateStat(targetEl, targetScore);
    updateStat(levelEl, level);
    updateStat(movesEl, movesLeft, movesLeft <= 5 ? "danger" : "");

    const pct = Math.min(100, Math.round((score / targetScore) * 100));
    progressEl.style.width = `${pct}%`;
    progressEl.setAttribute("aria-valuenow", pct);

    // Rebuild grid cells
    boardEl.innerHTML = "";
    boardEl.style.setProperty("--board-cols", size);

    for (let r = 0; r < size; r++) {
        for (let c = 0; c < size; c++) {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "cell";
            btn.dataset.row = r;
            btn.dataset.col = c;
            btn.setAttribute("role", "gridcell");

            const emoji = getCandyEmoji(board[r][c]);
            btn.textContent = emoji;
            btn.setAttribute(
                "aria-label",
                `${emoji}, row ${r + 1} column ${c + 1}`
            );

            if (selectedCell?.row === r && selectedCell?.col === c) {
                btn.classList.add("selected");
                btn.setAttribute("aria-selected", "true");
            } else {
                btn.setAttribute("aria-selected", "false");
            }

            btn.addEventListener("click", () => handleCellClick(r, c));
            boardEl.appendChild(btn);
        }
    }
}

/** Animates a numeric stat value change by adding a "bump" class. */
function updateStat(el, value, className = "") {
    const prev = el.textContent;
    const next = String(value);
    if (prev !== next) {
        el.textContent = next;
        el.classList.remove("bump");
        // Force reflow so the animation retriggers
        void el.offsetWidth;
        el.classList.add("bump");
    }
    el.style.color = className === "danger" ? "var(--danger)" : "";
}

// ---------------------------------------------------------------------------
// Message helper
// ---------------------------------------------------------------------------

let msgTimerId = null;

/** Displays a temporary message in the live region. */
function showMessage(text, durationMs = 2200) {
    messageEl.textContent = text;
    clearTimeout(msgTimerId);
    if (durationMs > 0) {
        msgTimerId = setTimeout(() => { messageEl.textContent = ""; }, durationMs);
    }
}

// ---------------------------------------------------------------------------
// Animation helpers
// ---------------------------------------------------------------------------

const delay = (ms) => new Promise((res) => setTimeout(res, ms));

/**
 * Adds the "matched" class to the cells at the given positions, waits for the
 * pop animation to complete, then resolves.
 */
async function animateMatchedCells(round) {
    const size = state.board.length;
    const cells = round
        .map((key) => {
            const [r, c] = key.split(",").map(Number);
            return boardEl.children[r * size + c];
        })
        .filter(Boolean);

    cells.forEach((el) => el.classList.add("matched"));
    await delay(380);
}

/**
 * Adds the "falling" class to cells that received new candies (previously
 * matched positions) so they appear to drop in from above.
 */
function animateNewCandies(matchedKeys) {
    const size = state.board.length;
    for (const key of matchedKeys) {
        const [r, c] = key.split(",").map(Number);
        const el = boardEl.children[r * size + c];
        if (el) {
            el.classList.add("falling");
            el.addEventListener(
                "animationend",
                () => el.classList.remove("falling"),
                { once: true }
            );
        }
    }
}

// ---------------------------------------------------------------------------
// Cell click handler
// ---------------------------------------------------------------------------

async function handleCellClick(row, col) {
    if (isAnimating) return;

    clearHintHighlights();

    const prevLevel = state.level;
    const { state: nextState, moveResult } = selectCell(state, row, col);

    if (!moveResult?.valid) {
        // Just a selection change — update immediately
        state = nextState;
        render();
        return;
    }

    // ---- Valid move: animate then update state ----
    isAnimating = true;

    // 1. Animate each cascade round on the CURRENT board before replacing it
    for (const round of moveResult.matchedCells) {
        await animateMatchedCells(round);
    }

    // 2. Commit the new state and re-render
    state = moveResult.state;
    render();

    // 3. Fly-in animation for cells that replaced matched ones
    const allMatched = new Set(moveResult.matchedCells.flat());
    animateNewCandies(allMatched);

    // 4. Combo message
    const totalCleared = moveResult.matchedCells.flat().length;
    if (moveResult.matchedCells.length >= 3) {
        showMessage("🔥 Blazing cascade!");
    } else if (totalCleared >= 6) {
        showMessage("🎉 Excellent combo!");
    } else if (totalCleared >= 4) {
        showMessage("✨ Nice move!");
    }

    // 5. Level-up notification
    if (state.level > prevLevel) {
        showMessage(`🎊 Level ${state.level}! Keep going!`, 3000);
    }

    isAnimating = false;

    // 6. Check game-over after a brief pause so the board settles visually
    if (isGameOver(state)) {
        await delay(600);
        showEndModal();
    }
}

// ---------------------------------------------------------------------------
// Hint
// ---------------------------------------------------------------------------

function clearHintHighlights() {
    clearTimeout(hintTimerId);
    boardEl.querySelectorAll(".cell.hinted").forEach((el) =>
        el.classList.remove("hinted")
    );
}

function handleHint() {
    if (isAnimating) return;

    clearHintHighlights();

    const hint = findHint(state.board, state.board.length);
    if (!hint) {
        showMessage("No valid moves left!", 2500);
        return;
    }

    const { row, col, direction } = hint;
    const size = state.board.length;
    const dr = { up: -1, down: 1, left: 0, right: 0 }[direction];
    const dc = { up: 0, down: 0, left: -1, right: 1 }[direction];

    const idx1 = row * size + col;
    const idx2 = (row + dr) * size + (col + dc);

    boardEl.children[idx1]?.classList.add("hinted");
    boardEl.children[idx2]?.classList.add("hinted");

    showMessage("💡 Swap the glowing candies!", 3000);
    hintTimerId = setTimeout(clearHintHighlights, 3000);
}

// ---------------------------------------------------------------------------
// End-of-game modal
// ---------------------------------------------------------------------------

function showEndModal() {
    const won = state.score >= state.targetScore;
    modalEmoji.textContent  = won ? "🎊" : "😢";
    modalTitle.textContent  = won ? "Level Complete!" : "Game Over!";
    modalMsg.textContent    = won
        ? `You scored ${state.score.toLocaleString()} points and reached Level ${state.level}!`
        : `You scored ${state.score.toLocaleString()} points. Better luck next time!`;
    modal.showModal();
}

function startNewGame() {
    clearHintHighlights();
    clearTimeout(msgTimerId);
    messageEl.textContent = "";
    if (modal.open) modal.close();
    state = newGame();
    render();
}

// ---------------------------------------------------------------------------
// Event listeners
// ---------------------------------------------------------------------------

document.getElementById("hint-btn").addEventListener("click", handleHint);
document.getElementById("new-game-btn").addEventListener("click", startNewGame);
document.getElementById("play-again-btn").addEventListener("click", startNewGame);

// Allow keyboard users to close modal with Escape (native dialog behaviour)
modal.addEventListener("cancel", (e) => {
    e.preventDefault(); // keep modal open; user must press Play Again
});

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------

render();
